import { useRef, useMemo } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Points, PointMaterial } from '@react-three/drei';

function StarField() {
  const ref = useRef<any>();
  
  // Generate random points for particles
  const particles = useMemo(() => {
    const positions = new Float32Array(2000 * 3);
    for (let i = 0; i < 2000; i++) {
      positions[i * 3] = (Math.random() - 0.5) * 10;
      positions[i * 3 + 1] = Math.random() * 10 - 5;
      positions[i * 3 + 2] = (Math.random() - 0.5) * 10;
    }
    return positions;
  }, []);

  useFrame((state, delta) => {
    if (ref.current) {
      ref.current.rotation.x -= delta / 10;
      ref.current.rotation.y -= delta / 15;
    }
  });

  return (
    <group rotation={[0, 0, Math.PI / 4]}>
      <Points ref={ref} positions={particles} stride={3} frustumCulled={false}>
        <PointMaterial
          transparent
          color="#00D4FF"
          size={0.002}
          sizeAttenuation={true}
          depthWrite={false}
        />
      </Points>
    </group>
  );
}

function GridField() {
  const ref = useRef<any>();
  
  useFrame((state, delta) => {
    if (ref.current) {
      ref.current.position.z = ((state.clock.elapsedTime * 0.5) % 4) - 2;
    }
  });

  const gridLines = useMemo(() => {
    const positions = [];
    const gridSize = 20;
    const divisions = 40;
    
    for (let i = 0; i <= divisions; i++) {
      const x = (i / divisions) * gridSize - gridSize / 2;
      positions.push(x, 0, -gridSize / 2, x, 0, gridSize / 2);
      positions.push(-gridSize / 2, 0, x, gridSize / 2, 0, x);
    }
    
    return new Float32Array(positions);
  }, []);

  return (
    <group ref={ref}>
      <lineSegments>
        <bufferGeometry>
          <bufferAttribute
            attach="attributes-position"
            array={gridLines}
            count={gridLines.length / 3}
            itemSize={3}
          />
        </bufferGeometry>
        <lineBasicMaterial color="#00FF88" transparent opacity={0.2} />
      </lineSegments>
    </group>
  );
}

export default function Background3D() {
  return (
    <div className="fixed inset-0 z-0">
      <Canvas
        camera={{ position: [0, 0, 1] }}
        style={{ background: 'transparent' }}
      >
        <StarField />
        <GridField />
      </Canvas>
    </div>
  );
}