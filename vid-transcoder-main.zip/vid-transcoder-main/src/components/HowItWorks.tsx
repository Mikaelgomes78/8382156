import { motion } from 'framer-motion';
import { Upload, Eye, Download, ArrowRight } from 'lucide-react';

export default function HowItWorks() {
  const steps = [
    {
      icon: Upload,
      title: 'Carregar o Vídeo',
      description: 'Faça upload do seu arquivo de vídeo. Suportamos MP4, AVI, MOV e outros formatos populares.',
      color: 'primary'
    },
    {
      icon: Eye,
      title: 'Análise de Quadros (OCR)',
      description: 'Nossa IA analisa cada quadro do vídeo, detectando e extraindo texto com precisão avançada.',
      color: 'secondary'
    },
    {
      icon: Download,
      title: 'Exportar o SRT',
      description: 'Receba seu arquivo de legendas SRT pronto, com timestamps precisos e texto formatado.',
      color: 'accent'
    }
  ];

  return (
    <section id="how-it-works" className="py-20 relative">
      <div className="container mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-heading font-bold mb-6">
            <span className="holographic-text">Como Funciona</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Processo simples e automatizado em apenas 3 passos
          </p>
        </motion.div>

        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 relative">
            {/* Connection Lines */}
            <div className="hidden md:block absolute top-1/2 left-1/3 w-1/3 h-0.5 bg-gradient-to-r from-primary to-secondary transform -translate-y-1/2" />
            <div className="hidden md:block absolute top-1/2 right-1/3 w-1/3 h-0.5 bg-gradient-to-r from-secondary to-accent transform -translate-y-1/2" />

            {steps.map((step, index) => (
              <motion.div
                key={step.title}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.2, duration: 0.6 }}
                viewport={{ once: true }}
                whileHover={{ scale: 1.05 }}
                className="relative z-10"
              >
                <div className="glass-card p-8 rounded-2xl text-center h-full relative overflow-hidden group">
                  {/* Scan Line Effect */}
                  <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                    <div className="scan-line h-full w-full" />
                  </div>

                  {/* Step Number */}
                  <div className="absolute -top-4 -right-4 w-12 h-12 bg-gradient-primary rounded-full flex items-center justify-center text-lg font-bold">
                    {index + 1}
                  </div>

                  {/* Icon */}
                  <motion.div
                    whileHover={{ rotateY: 180 }}
                    transition={{ duration: 0.6 }}
                    className={`w-20 h-20 mx-auto mb-6 rounded-full bg-gradient-${step.color} flex items-center justify-center relative group-hover:shadow-neon-${step.color}`}
                  >
                    <step.icon className="w-10 h-10 text-white" />
                    
                    {/* Rotating border */}
                    <motion.div
                      animate={{ rotate: 360 }}
                      transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
                      className={`absolute inset-0 border-2 border-${step.color} rounded-full opacity-30`}
                    />
                  </motion.div>

                  {/* Content */}
                  <h3 className="text-2xl font-heading font-semibold mb-4 text-foreground">
                    {step.title}
                  </h3>
                  <p className="text-muted-foreground leading-relaxed">
                    {step.description}
                  </p>

                  {/* Arrow for mobile */}
                  {index < steps.length - 1 && (
                    <motion.div
                      animate={{ x: [0, 10, 0] }}
                      transition={{ duration: 2, repeat: Infinity }}
                      className="md:hidden flex justify-center mt-8"
                    >
                      <ArrowRight className="w-6 h-6 text-primary" />
                    </motion.div>
                  )}
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Additional Info */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8, duration: 0.6 }}
          viewport={{ once: true }}
          className="mt-16 text-center"
        >
          <div className="glass-card p-8 rounded-2xl max-w-4xl mx-auto">
            <h3 className="text-2xl font-heading font-semibold mb-4 text-secondary">
              Tecnologia de Ponta
            </h3>
            <p className="text-muted-foreground text-lg leading-relaxed">
              Utilizamos algoritmos de Machine Learning e processamento de imagem avançado 
              para garantir a máxima precisão na extração de texto. Nosso sistema funciona 
              100% offline, garantindo total privacidade dos seus dados.
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  );
}