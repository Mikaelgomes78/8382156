import { motion } from 'framer-motion';
import { Eye, Github, Mail, Twitter } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="py-12 border-t border-border/20 relative">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Logo & Description */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="col-span-1 md:col-span-2"
          >
            <div className="flex items-center space-x-3 mb-4">
              <div className="relative">
                <Eye className="w-8 h-8 text-primary" />
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
                  className="absolute inset-0 border-2 border-primary rounded-full opacity-30"
                />
              </div>
              <div>
                <h3 className="text-xl font-heading font-bold holographic-text">
                  PROJETO OCR
                </h3>
                <p className="text-xs text-muted-foreground">
                  AI Video Transcription
                </p>
              </div>
            </div>
            <p className="text-muted-foreground max-w-md leading-relaxed">
              Transformando a maneira como você extrai texto de vídeos. 
              Tecnologia de ponta para transcrição precisa e eficiente.
            </p>
          </motion.div>

          {/* Links */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2, duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h4 className="font-heading font-semibold text-foreground mb-4">
              Navegação
            </h4>
            <ul className="space-y-2">
              {[
                { label: 'Início', href: '#hero' },
                { label: 'Como Funciona', href: '#how-it-works' },
                { label: 'Recursos', href: '#features' },
                { label: 'Tecnologias', href: '#technologies' },
              ].map((link) => (
                <li key={link.label}>
                  <motion.a
                    href={link.href}
                    whileHover={{ x: 5 }}
                    className="text-muted-foreground hover:text-primary transition-colors text-sm"
                  >
                    {link.label}
                  </motion.a>
                </li>
              ))}
            </ul>
          </motion.div>

          {/* Social */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h4 className="font-heading font-semibold text-foreground mb-4">
              Conecte-se
            </h4>
            <div className="flex space-x-4">
              {[
                { icon: Github, href: '#', color: 'primary' },
                { icon: Twitter, href: '#', color: 'secondary' },
                { icon: Mail, href: '#', color: 'accent' },
              ].map((social, index) => (
                <motion.a
                  key={index}
                  href={social.href}
                  whileHover={{ scale: 1.1, y: -2 }}
                  whileTap={{ scale: 0.95 }}
                  className={`w-10 h-10 rounded-lg bg-gradient-${social.color} flex items-center justify-center hover:shadow-neon-${social.color} transition-shadow duration-300`}
                >
                  <social.icon className="w-5 h-5 text-white" />
                </motion.a>
              ))}
            </div>
          </motion.div>
        </div>

        {/* Bottom Bar */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ delay: 0.6, duration: 0.6 }}
          viewport={{ once: true }}
          className="mt-12 pt-8 border-t border-border/20 text-center"
        >
          <p className="text-muted-foreground text-sm">
            © 2024 Projeto OCR. Feito com{' '}
            <motion.span
              animate={{ scale: [1, 1.2, 1] }}
              transition={{ duration: 1, repeat: Infinity }}
              className="text-red-500"
            >
              ❤️
            </motion.span>{' '}
            e tecnologia de ponta.
          </p>
        </motion.div>
      </div>
    </footer>
  );
}