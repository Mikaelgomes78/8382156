import { motion } from 'framer-motion';
import { 
  Shield, 
  Zap, 
  Settings, 
  Download, 
  BarChart3, 
  Edit3,
  Clock,
  Cpu
} from 'lucide-react';

export default function Features() {
  const features = [
    {
      icon: Shield,
      title: 'Funcionalidade Offline',
      description: 'Processe seus vídeos com total privacidade. Nenhum dado é enviado para servidores externos.',
      color: 'primary'
    },
    {
      icon: BarChart3,
      title: 'Barra de Progresso',
      description: 'Acompanhe o progresso da análise em tempo real com indicadores visuais detalhados.',
      color: 'secondary'
    },
    {
      icon: Edit3,
      title: 'Edição de Legendas',
      description: 'Editor integrado para ajustar e corrigir as legendas antes da exportação final.',
      color: 'accent'
    },
    {
      icon: Zap,
      title: 'Processamento Rápido',
      description: 'Engine otimizada que processa vídeos até 10x mais rápido que soluções tradicionais.',
      color: 'primary'
    },
    {
      icon: Clock,
      title: 'Timestamps Precisos',
      description: 'Sincronização perfeita entre texto e tempo, com precisão de milissegundos.',
      color: 'secondary'
    },
    {
      icon: Download,
      title: 'Múltiplos Formatos',
      description: 'Exporte em SRT, VTT, ASS e outros formatos populares de legendas.',
      color: 'accent'
    },
    {
      icon: Settings,
      title: 'IA Configurável',
      description: 'Ajuste parâmetros de detecção e reconhecimento para diferentes tipos de conteúdo.',
      color: 'primary'
    },
    {
      icon: Cpu,
      title: 'Multi-threading',
      description: 'Utiliza todos os núcleos do processador para máximo desempenho na análise.',
      color: 'secondary'
    }
  ];

  return (
    <section id="features" className="py-20 relative">
      <div className="container mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-heading font-bold mb-6">
            <span className="holographic-text">Recursos Avançados</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Tecnologia de ponta para transcrição precisa e eficiente
          </p>
        </motion.div>

        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 50, rotateX: -15 }}
                whileInView={{ opacity: 1, y: 0, rotateX: 0 }}
                transition={{ 
                  delay: index * 0.1, 
                  duration: 0.6,
                  type: "spring",
                  stiffness: 100
                }}
                viewport={{ once: true }}
                whileHover={{ 
                  scale: 1.05, 
                  rotateY: 5,
                  transition: { duration: 0.3 }
                }}
                className="group relative"
              >
                <div className="glass-card p-6 rounded-2xl h-full relative overflow-hidden transition-all duration-300">
                  {/* Hover glow effect */}
                  <div className={`absolute inset-0 bg-gradient-${feature.color} opacity-0 group-hover:opacity-5 transition-opacity duration-300 rounded-2xl`} />
                  
                  {/* Floating particles on hover */}
                  <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                    {[...Array(3)].map((_, i) => (
                      <motion.div
                        key={i}
                        className={`absolute w-1 h-1 bg-${feature.color} rounded-full`}
                        style={{
                          left: `${20 + i * 30}%`,
                          top: `${20 + i * 20}%`,
                        }}
                        animate={{
                          y: [-10, -30, -10],
                          opacity: [0, 1, 0],
                        }}
                        transition={{
                          duration: 2,
                          repeat: Infinity,
                          delay: i * 0.3,
                        }}
                      />
                    ))}
                  </div>

                  {/* Icon */}
                  <motion.div
                    whileHover={{ scale: 1.2, rotateZ: 10 }}
                    transition={{ duration: 0.3 }}
                    className={`w-16 h-16 mx-auto mb-4 rounded-xl bg-gradient-${feature.color} flex items-center justify-center group-hover:shadow-neon-${feature.color} transition-shadow duration-300`}
                  >
                    <feature.icon className="w-8 h-8 text-white" />
                  </motion.div>

                  {/* Content */}
                  <div className="text-center relative z-10">
                    <h3 className="text-lg font-heading font-semibold mb-3 text-foreground group-hover:text-primary transition-colors duration-300">
                      {feature.title}
                    </h3>
                    <p className="text-sm text-muted-foreground leading-relaxed group-hover:text-foreground/80 transition-colors duration-300">
                      {feature.description}
                    </p>
                  </div>

                  {/* Bottom accent line */}
                  <motion.div
                    initial={{ width: 0 }}
                    whileInView={{ width: "100%" }}
                    transition={{ delay: index * 0.1 + 0.5, duration: 0.8 }}
                    viewport={{ once: true }}
                    className={`absolute bottom-0 left-0 h-0.5 bg-gradient-${feature.color}`}
                  />
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Call to Action */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8, duration: 0.6 }}
          viewport={{ once: true }}
          className="mt-16 text-center"
        >
          <motion.div
            whileHover={{ scale: 1.02 }}
            className="glass-card p-8 rounded-2xl max-w-2xl mx-auto relative overflow-hidden group"
          >
            <div className="absolute inset-0 bg-gradient-holographic opacity-5 group-hover:opacity-10 transition-opacity duration-300" />
            <h3 className="text-2xl font-heading font-semibold mb-4 holographic-text">
              Pronto para Experimentar?
            </h3>
            <p className="text-muted-foreground mb-6">
              Teste todas essas funcionalidades agora mesmo. Sem cadastro, sem limites.
            </p>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="bg-gradient-primary px-8 py-3 rounded-lg font-semibold hover:shadow-neon-primary transition-all duration-300"
            >
              Começar Agora
            </motion.button>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}