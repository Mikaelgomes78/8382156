import { motion } from 'framer-motion';

export default function Technologies() {
  const technologies = [
    {
      name: 'React',
      description: 'Interface moderna e responsiva',
      icon: '⚛️',
      color: 'primary'
    },
    {
      name: 'OpenCV',
      description: 'Processamento avançado de imagem',
      icon: '👁️',
      color: 'secondary'
    },
    {
      name: 'Tesseract',
      description: 'Engine OCR de alta precisão',
      icon: '🔍',
      color: 'accent'
    },
    {
      name: 'TensorFlow',
      description: 'Machine Learning para IA',
      icon: '🤖',
      color: 'primary'
    },
    {
      name: 'FFmpeg',
      description: 'Processamento de vídeo otimizado',
      icon: '🎬',
      color: 'secondary'
    },
    {
      name: 'WebAssembly',
      description: 'Performance nativa no browser',
      icon: '⚡',
      color: 'accent'
    },
    {
      name: 'TypeScript',
      description: 'Código robusto e tipado',
      icon: '💎',
      color: 'primary'
    },
    {
      name: 'Electron',
      description: 'App desktop multiplataforma',
      icon: '🖥️',
      color: 'secondary'
    }
  ];

  return (
    <section id="technologies" className="py-20 relative">
      <div className="container mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-heading font-bold mb-6">
            <span className="holographic-text">Tecnologias</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Stack tecnológico moderno para máximo desempenho
          </p>
        </motion.div>

        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {technologies.map((tech, index) => (
              <motion.div
                key={tech.name}
                initial={{ opacity: 0, scale: 0.8, rotateY: -90 }}
                whileInView={{ opacity: 1, scale: 1, rotateY: 0 }}
                transition={{ 
                  delay: index * 0.1, 
                  duration: 0.6,
                  type: "spring",
                  stiffness: 100
                }}
                viewport={{ once: true }}
                whileHover={{ 
                  scale: 1.1, 
                  rotateY: 15,
                  rotateX: 10,
                  transition: { duration: 0.3 }
                }}
                className="group relative perspective-1000"
              >
                <motion.div
                  whileHover={{ rotateZ: [0, -5, 5, -5, 0] }}
                  transition={{ duration: 0.5 }}
                  className="glass-card p-6 rounded-2xl text-center h-full relative overflow-hidden"
                >
                  {/* Animated background */}
                  <div className={`absolute inset-0 bg-gradient-${tech.color} opacity-0 group-hover:opacity-10 transition-opacity duration-300 rounded-2xl`} />
                  
                  {/* Pulsing ring effect */}
                  <motion.div
                    animate={{ 
                      scale: [1, 1.2, 1],
                      opacity: [0.3, 0.1, 0.3]
                    }}
                    transition={{ 
                      duration: 3,
                      repeat: Infinity,
                      ease: "easeInOut"
                    }}
                    className={`absolute inset-4 border-2 border-${tech.color} rounded-full opacity-0 group-hover:opacity-30`}
                  />

                  {/* Icon */}
                  <motion.div
                    whileHover={{ 
                      scale: 1.3,
                      rotate: 360
                    }}
                    transition={{ duration: 0.6 }}
                    className="text-4xl mb-4 relative z-10"
                  >
                    {tech.icon}
                  </motion.div>

                  {/* Content */}
                  <div className="relative z-10">
                    <h3 className="text-lg font-heading font-semibold mb-2 text-foreground group-hover:text-primary transition-colors duration-300">
                      {tech.name}
                    </h3>
                    <p className="text-xs text-muted-foreground group-hover:text-foreground/80 transition-colors duration-300">
                      {tech.description}
                    </p>
                  </div>

                  {/* Corner accent */}
                  <div className={`absolute top-0 right-0 w-8 h-8 bg-gradient-${tech.color} opacity-20 transform rotate-45 translate-x-4 -translate-y-4`} />
                </motion.div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Tech Stats */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8, duration: 0.6 }}
          viewport={{ once: true }}
          className="mt-16"
        >
          <div className="glass-card p-8 rounded-2xl max-w-4xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
              <motion.div
                whileHover={{ scale: 1.05 }}
                className="group"
              >
                <div className="text-3xl font-heading font-bold text-primary mb-2 group-hover:animate-pulse-neon">
                  8+
                </div>
                <div className="text-sm text-muted-foreground uppercase tracking-wide">
                  Tecnologias Modernas
                </div>
              </motion.div>
              <motion.div
                whileHover={{ scale: 1.05 }}
                className="group"
              >
                <div className="text-3xl font-heading font-bold text-secondary mb-2 group-hover:animate-pulse-neon">
                  100%
                </div>
                <div className="text-sm text-muted-foreground uppercase tracking-wide">
                  Open Source
                </div>
              </motion.div>
              <motion.div
                whileHover={{ scale: 1.05 }}
                className="group"
              >
                <div className="text-3xl font-heading font-bold text-accent mb-2 group-hover:animate-pulse-neon">
                  Zero
                </div>
                <div className="text-sm text-muted-foreground uppercase tracking-wide">
                  Dependências Externas
                </div>
              </motion.div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}