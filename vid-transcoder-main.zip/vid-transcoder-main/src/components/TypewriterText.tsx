import { useState, useEffect } from 'react';

interface TypewriterTextProps {
  text: string;
  delay?: number;
  className?: string;
  onComplete?: () => void;
}

export default function TypewriterText({ 
  text, 
  delay = 100, 
  className = "", 
  onComplete 
}: TypewriterTextProps) {
  const [displayedText, setDisplayedText] = useState('');
  const [isComplete, setIsComplete] = useState(false);

  useEffect(() => {
    if (displayedText === text) {
      setIsComplete(true);
      onComplete?.();
      return;
    }

    const timeout = setTimeout(() => {
      setDisplayedText(text.slice(0, displayedText.length + 1));
    }, delay);

    return () => clearTimeout(timeout);
  }, [displayedText, text, delay, onComplete]);

  return (
    <span className={`${className} ${!isComplete ? 'typing-cursor' : ''}`}>
      {displayedText}
    </span>
  );
}